TOKEN = "@alexy_xexio" #7971593718:AAEvmgn5PzJub2U3sUtAzMzz32kGHEL1rZg
CRYPTO_TOKEN = "@alexy_xexio" #298406:AAe1PywCJmWXBdqE0CxDpkzgqosIootU2Ef
LOG_CHANNEL = -1002356237051 #ЛОГИРОВАНИЕ
CHANNEL_BROKER = -1002356237051 #Посредник
MAIN_CHANNEL= -1002356237051 #основа
ADMINS = [6275464481] #список админов
CHECK_URL = "t.me/send?start=IVxmE8f9Dpq6" #юрл счёта
MONEYBACK = 20 #процент манибэка от игры
